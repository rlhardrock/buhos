<?php
/**************
 * @package WordPress
 * @subpackage Cuckoothemes
 * @since Cuckoothemes 1.0
 **************/

get_header(); 
get_template_part( 'loop', 'index' );
get_footer(); 
?>