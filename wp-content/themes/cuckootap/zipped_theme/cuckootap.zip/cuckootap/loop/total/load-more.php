<?php
/**************
* @package WordPress
* @subpackage Cuckoothemes
* @since Cuckoothemes 1.0
* URL http://cuckoothemes.com
**************
*
*
*
** Name : Load More
*/

?>
<section id="load-more-position" title="<?php _e('Load More', THEMENAME); ?>">
	<div class="testimonials-shadow"></div>
	<div class="load-more"></div>
</section>