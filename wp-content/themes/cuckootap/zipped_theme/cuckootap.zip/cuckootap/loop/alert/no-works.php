<?php
/**************
* @package WordPress
* @subpackage Cuckoothemes
* @since Cuckoothemes 1.0
**************
*
*
*
** Name: No works
*/
?>
<div id="item-alert">
	<div class="item-alert-box">
		<div class="item-alert-text">
			<div class="item-alert-image-mark"></div>
			<span><?php _e('There are no items to display.<br /> Please add at least one work.', THEMENAME); ?></span>
		</div>
	</div>
</div>